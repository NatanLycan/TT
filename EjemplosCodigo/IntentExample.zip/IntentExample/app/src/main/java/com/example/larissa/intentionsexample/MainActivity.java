package com.example.larissa.intentionsexample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    // Creo EXTRAS para mis intents
    public final static String EXTRA_MESSAGE = "constante pública";

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }


    /*  FUNCIÓN NLJS:   sendMessage()
    *   Lanza un mensaje cuando se presiona el botón.
    *   Para que el sistema haga coincidir este método con el nombre del método proporcionado a android:onClick:
    *       -Ser público
    *       -Tener un valor de retorno vacío
    *       -Tener un View como el único parámetro (view al que se le hizó clic)
    * */
    public void sendMessage(View view) {
        // Un Intent es un objeto que proporciona enlace de tiempo de ejecución entre componentes separados (como dos actividades).

        // El constructor de Intent toma dos parámetros:
        //  -Context: se usa this porque la clase Activity es una subclase de Context
        //  -La Class del componente de la app a la cual el sistema debe entregar la Intent
        //   (en este caso, la actividad que debería iniciarse).
        Intent intent = new Intent(this, DisplayMessageActivity.class);

        EditText editText = (EditText) findViewById(R.id.edit_message);
        String message = editText.getText().toString();

        // putExtra agrega el valor del mensaje al intent.
        // Una Intent puede llevar tipos de datos como pares clave-valor denominados extra.
        intent.putExtra(EXTRA_MESSAGE, message);

        // Se inicia la una instancia especificadad en el constructor del intent (DisplayMessageActivity)
        startActivity(intent);

        // Crear actividad (DisplayMessageActivity) desde el menú de Android Studio  Project > New > Activity > Empty Activity.
        // Esto genera DisplayMessageActivity.java, DisplayMessageActivity.xml y agrega la nueva actividad en AndroidManifest.xml
    }

}